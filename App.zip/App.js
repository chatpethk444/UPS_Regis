// App.js — Root Component (ลดจาก ~1,256 บรรทัด เหลือแค่ router กลาง)
import React, { useState } from "react";
import { Alert } from "react-native";

import { loginAPI, batchAddRequiredAPI } from "./api";

import LoginScreen    from "./screens/LoginScreen";
import MenuScreen     from "./screens/MenuScreen";
import ManualScreen   from "./screens/ManualScreen";
import AIScreen       from "./screens/AIScreen";
import CartScreen     from "./screens/CartScreen";
import ScheduleScreen from "./screens/ScheduleScreen";

export default function App() {
  const [view, setView]       = useState("LOGIN");
  const [student, setStudent] = useState(null);
  const [loading, setLoading] = useState(false);

  // --- Login ---
  const handleLogin = async (sid, pw) => {
    setLoading(true);
    try {
      const data = await loginAPI(sid, pw);
      setStudent(data);
      setView("MENU");
    } catch (e) {
      Alert.alert("เข้าสู่ระบบล้มเหลว", e.message);
    } finally {
      setLoading(false);
    }
  };

  // --- Batch ---
  const handleBatchRegis = () => {
    Alert.alert("Batch Registration", "เพิ่มวิชาบังคับลงตะกร้า?", [
      { text: "ยกเลิก" },
      {
        text: "ตกลง",
        onPress: async () => {
          try {
            const count = await batchAddRequiredAPI(student.student_id);
            Alert.alert("สำเร็จ", `เพิ่ม ${count} วิชาบังคับลงตะกร้าแล้ว!`);
          } catch (e) {
            Alert.alert("Error", e.message);
          }
        },
      },
    ]);
  };

  // --- Logout ---
  const handleLogout = () => {
    setStudent(null);
    setView("LOGIN");
  };

  // --- Router ---
  const screens = {
    LOGIN:    <LoginScreen    loading={loading} onLogin={handleLogin} />,
    MENU:     <MenuScreen     student={student} setView={setView} onBatch={handleBatchRegis} onLogout={handleLogout} />,
    MANUAL:   <ManualScreen   student={student} setView={setView} />,
    AI:       <AIScreen       student={student} setView={setView} />,
    CART:     <CartScreen     student={student} setView={setView} />,
    SCHEDULE: <ScheduleScreen student={student} setView={setView} />,
  };

  return screens[view] ?? screens["LOGIN"];
}
