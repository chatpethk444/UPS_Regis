// screens/MenuScreen.js
// screens/MenuScreen.js
import React from 'react';
import { View, Text, StyleSheet, SafeAreaView, Image, TouchableOpacity, ScrollView } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

export default function MenuScreen({ student, setView, onBatch, onLogout }) {
  // คำนวณชั้นปีแบบคร่าวๆ (ถ้ามีข้อมูลปีการศึกษาใน DB)
  const year = student?.year ? (2569 - parseInt(student.year)) : "?";

  return (
    <SafeAreaView style={styles.container}>
      {/* Top AppBar */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          {/* ปุ่มย้อนกลับ (ใช้เป็นปุ่มออกจากระบบ) */}
          <TouchableOpacity 
            onPress={onLogout} 
            style={styles.backButton}
          >
            <MaterialIcons name="arrow-back" size={24} color="#7b5455" />
          </TouchableOpacity>
          
          {/* โลโก้และชื่อแอป */}
          <MaterialIcons name="menu-book" size={24} color="#7b5455" />
          <Text style={styles.headerTitle}>Scholastic Curator</Text>
        </View>

        {/* ปุ่มกระดิ่งแจ้งเตือน */}
        <TouchableOpacity style={styles.bellButton}>
          <MaterialIcons name="notifications" size={22} color="#7b5455" />
          <View style={styles.notificationDot} />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Student Profile Header */}
        <View style={styles.profileSection}>
          <View style={styles.profileImageContainer}>
            {/* รูปโปรไฟล์ */}
            <Image 
              source={{ uri: 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png' }} 
              style={styles.profileImage}
            />
          </View>
          <View style={styles.profileInfo}>
            <Text style={styles.greeting}>ยินดีต้อนรับกลับ,</Text>
            {/* ดึงชื่อจริงจาก Database มาแสดง */}
            <Text style={styles.studentName}>{student?.first_name || "นักศึกษา"}</Text>
            <Text style={styles.studentId}>
              {student?.major || "ไม่ระบุสาขา"} • ปี {year}
            </Text>
            <Text style={styles.studentId}>รหัสนักศึกษา: {student?.student_id || "N/A"}</Text>
          </View>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statBox}>
            <MaterialIcons name="grade" size={20} color="#a73355" />
            <Text style={styles.statValue}>3.85</Text>
            <Text style={styles.statLabel}>เกรดเฉลี่ยสะสม</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statBox}>
            <MaterialIcons name="school" size={20} color="#a73355" />
            <Text style={styles.statValue}>45/120</Text>
            <Text style={styles.statLabel}>หน่วยกิตที่เก็บได้</Text>
          </View>
        </View>

        {/* Main Features Grid */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>ฟีเจอร์หลัก</Text>
        </View>
        
        <View style={styles.gridContainer}>
          {/* 1. ค้นหาวิชาเรียน (Manual) */}
          <TouchableOpacity style={styles.gridItem} onPress={() => setView("MANUAL")}>
            <View style={styles.iconContainer}>
              <MaterialIcons name="search" size={28} color="#a73355" />
            </View>
            <Text style={styles.gridText}>ค้นหาวิชาเรียน</Text>
          </TouchableOpacity>

          {/* 2. ตะกร้าของฉัน (Cart) */}
          <TouchableOpacity style={styles.gridItem} onPress={() => setView("CART")}>
            <View style={styles.iconContainer}>
              <MaterialIcons name="shopping-cart" size={28} color="#a73355" />
              {/* จุดแจ้งเตือนสีแดง (Optional) */}
              <View style={styles.cartBadge} />
            </View>
            <Text style={styles.gridText}>ตะกร้าของฉัน</Text>
          </TouchableOpacity>

          {/* 3. จัดตารางอัตโนมัติ (AI) */}
          <TouchableOpacity style={styles.gridItem} onPress={() => setView("AI")}>
            <View style={styles.iconContainer}>
              <MaterialIcons name="auto-awesome" size={28} color="#a73355" />
            </View>
            <Text style={styles.gridText}>จัดตารางอัตโนมัติ</Text>
          </TouchableOpacity>

          {/* 4. ตารางเรียน (Schedule) */}
          <TouchableOpacity style={styles.gridItem} onPress={() => setView("SCHEDULE")}>
            <View style={styles.iconContainer}>
              <MaterialIcons name="event-note" size={28} color="#a73355" />
            </View>
            <Text style={styles.gridText}>ตารางเรียนของฉัน</Text>
          </TouchableOpacity>

          {/* 5. ลงทะเบียนยกชุด (Batch) */}
          <TouchableOpacity style={styles.gridItem} onPress={onBatch}>
            <View style={styles.iconContainer}>
              <MaterialIcons name="fact-check" size={28} color="#a73355" />
            </View>
            <Text style={styles.gridText}>ลงทะเบียนยกชุด</Text>
          </TouchableOpacity>

          {/* 6. ออกจากระบบ (Logout) */}
          <TouchableOpacity style={styles.gridItem} onPress={onLogout}>
            <View style={[styles.iconContainer, { backgroundColor: '#ffebee' }]}>
              <MaterialIcons name="logout" size={28} color="#d32f2f" />
            </View>
            <Text style={[styles.gridText, { color: '#d32f2f' }]}>ออกจากระบบ</Text>
          </TouchableOpacity>
        </View>

        {/* ข่าวสารและประกาศ (UI Dummy) */}
        <View style={[styles.sectionHeader, { marginTop: 24 }]}>
          <Text style={styles.sectionTitle}>ประกาศสำคัญ</Text>
          <TouchableOpacity>
            <Text style={styles.seeAllText}>ดูทั้งหมด</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.newsCard}>
          <View style={styles.newsIconBox}>
            <MaterialIcons name="campaign" size={24} color="#fff" />
          </View>
          <View style={styles.newsContent}>
            <Text style={styles.newsTitle}>เปิดระบบลงทะเบียนเรียน</Text>
            <Text style={styles.newsDesc}>ภาคเรียนที่ 1/2567 จะเริ่มเปิดระบบในวันที่ 15 สิงหาคมนี้</Text>
          </View>
        </View>

      </ScrollView>

      {/* Bottom Navigation */}
      <View style={styles.bottomNav}>
        <TouchableOpacity style={styles.navItemActive}>
          <MaterialIcons name="home" size={24} color="#a73355" />
          <Text style={styles.navTextActive}>หน้าแรก</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => setView("MANUAL")}>
          <MaterialIcons name="search" size={24} color="#837375" />
          <Text style={styles.navText}>ค้นหา</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => setView("CART")}>
          <MaterialIcons name="shopping-cart" size={24} color="#837375" />
          <Text style={styles.navText}>ตะกร้า</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => setView("SCHEDULE")}>
          <MaterialIcons name="person" size={24} color="#837375" />
          <Text style={styles.navText}>โปรไฟล์</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fcf6f7' },
  scrollContent: { paddingBottom: 100 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', paddingHorizontal: 24, marginBottom: 16 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', color: '#1f1a1c' },
  seeAllText: { fontSize: 12, color: '#a73355', fontWeight: 'bold' },
  gridContainer: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 16, justifyContent: 'space-between' },
  gridItem: { width: '30%', alignItems: 'center', marginBottom: 24 },
  iconContainer: { width: 64, height: 64, backgroundColor: '#fff', borderRadius: 20, justifyContent: 'center', alignItems: 'center', shadowColor: '#a73355', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.1, shadowRadius: 12, elevation: 4, marginBottom: 8, position: 'relative' },
  cartBadge: { position: 'absolute', top: 12, right: 12, width: 10, height: 10, backgroundColor: '#e53935', borderRadius: 5, borderWidth: 1.5, borderColor: '#fff' },
  gridText: { fontSize: 11, fontWeight: '600', color: '#514345', textAlign: 'center' },
  newsCard: { flexDirection: 'row', backgroundColor: '#fff', marginHorizontal: 24, padding: 16, borderRadius: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 8, elevation: 2 },
  newsIconBox: { width: 48, height: 48, backgroundColor: '#a73355', borderRadius: 16, justifyContent: 'center', alignItems: 'center', marginRight: 16 },
  newsContent: { flex: 1, justifyContent: 'center' },
  newsTitle: { fontSize: 14, fontWeight: 'bold', color: '#1f1a1c', marginBottom: 4 },
  newsDesc: { fontSize: 12, color: '#837375', lineHeight: 18 },
  profileSection: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 24, paddingTop: 8, paddingBottom: 24 },
  profileImageContainer: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#fff', padding: 4, shadowColor: '#a73355', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.15, shadowRadius: 12, elevation: 6 },
  profileImage: { width: '100%', height: '100%', borderRadius: 36 },
  profileInfo: { flex: 1, marginLeft: 20 },
  greeting: { fontSize: 14, color: '#837375', marginBottom: 2 },
  studentName: { fontSize: 22, fontWeight: 'bold', color: '#1f1a1c', marginBottom: 4 },
  studentId: { fontSize: 12, color: '#a73355', fontWeight: '500' },
  statsContainer: { flexDirection: 'row', backgroundColor: '#fff', marginHorizontal: 24, paddingVertical: 16, borderRadius: 24, marginBottom: 32, shadowColor: '#a73355', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.08, shadowRadius: 16, elevation: 4 },
  statBox: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  statDivider: { width: 1, backgroundColor: '#f0e6e8', marginVertical: 8 },
  statValue: { fontSize: 20, fontWeight: 'bold', color: '#1f1a1c', marginTop: 8, marginBottom: 4 },
  statLabel: { fontSize: 11, color: '#837375' },
  bottomNav: { position: 'absolute', bottom: 0, width: '100%', flexDirection: 'row', justifyContent: 'space-around', backgroundColor: 'rgba(255, 248, 248, 0.95)', paddingBottom: 24, paddingTop: 16, borderTopLeftRadius: 32, borderTopRightRadius: 32 },
  navItemActive: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f5ebed', paddingHorizontal: 20, paddingVertical: 8, borderRadius: 20 },
  navTextActive: { fontSize: 12, fontWeight: 'bold', color: '#a73355', marginLeft: 8 },
  navItem: { alignItems: 'center', paddingHorizontal: 20, paddingVertical: 8, justifyContent: 'center' },
  navText: { fontSize: 10, fontWeight: 'bold', color: '#837375', marginTop: 4 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingTop: 16, paddingBottom: 16, zIndex: 10 },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  backButton: { padding: 4, marginLeft: -4 },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#7b5455', marginLeft: 4, letterSpacing: 0.5 },
  bellButton: { padding: 8, position: 'relative' },
  notificationDot: { position: 'absolute', top: 8, right: 8, width: 8, height: 8, backgroundColor: '#e53935', borderRadius: 4, borderWidth: 1.5, borderColor: '#fcf6f7' },
});