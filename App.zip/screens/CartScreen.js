// screens/CartScreen.js
import React, { useState, useEffect } from "react";
import {
  View, Text, FlatList, TouchableOpacity,
  Alert, ActivityIndicator, SafeAreaView,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { ScreenHeader, CourseBadge, COLORS, sharedStyles } from "../components/shared";
import { getCartAPI, removeFromCartAPI, confirmEnrollmentAPI } from "../api";

export default function CartScreen({ student, setView }) {
  const [items, setItems]           = useState([]);
  const [loadingCart, setLoadingCart] = useState(false);

  useEffect(() => { fetchCart(); }, []);

  const fetchCart = async () => {
    setLoadingCart(true);
    try {
      const data = await getCartAPI(student.student_id);
      // จัดกลุ่มวิชาเดียวกันไว้ด้วยกัน
      const grouped = data.reduce((acc, item) => {
        const code = item.course_code;
        if (!code) return acc;
        if (!acc[code]) {
          acc[code] = { course_code: code, course_name: item.course_name, time_info: item.time_info || "", sections: [] };
        }
        if (!acc[code].sections.includes(item.section_number)) {
          acc[code].sections.push(item.section_number);
        }
        return acc;
      }, {});
      setItems(Object.values(grouped));
    } catch (e) {
      Alert.alert("Error", e.message);
    } finally {
      setLoadingCart(false);
    }
  };

  // ✅ นับหน่วยกิตรวม (แสดงในหน้า Cart)
  const totalCredits = items.reduce((sum, item) => {
    const c = parseInt(item.credits) || 3;
    return sum + c;
  }, 0);

  const removeItem = (courseCode) => {
    Alert.alert("ลบวิชา", `ต้องการลบ ${courseCode} ออกจากตะกร้าหรือไม่?`, [
      { text: "ยกเลิก", style: "cancel" },
      {
        text: "ลบ", style: "destructive",
        onPress: async () => {
          try {
            await removeFromCartAPI(student.student_id, courseCode);
            setItems((prev) => prev.filter((i) => i.course_code !== courseCode));
          } catch (e) {
            Alert.alert("ข้อผิดพลาด", e.message);
          }
        },
      },
    ]);
  };

  const confirmRegistration = () => {
    Alert.alert("ยืนยัน", "ต้องการลงทะเบียนวิชาในตะกร้าทั้งหมดหรือไม่?", [
      { text: "ยกเลิก", style: "cancel" },
      {
        text: "ยืนยัน",
        onPress: async () => {
          try {
            await confirmEnrollmentAPI(student.student_id);
            Alert.alert("สำเร็จ", "ลงทะเบียนเรียบร้อย!");
            setView("SCHEDULE");
          } catch (e) {
            Alert.alert("ข้อผิดพลาด", e.message);
          }
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={sharedStyles.container}>
      <ScreenHeader title="ตะกร้า" onBack={() => setView("MENU")} />

      {loadingCart ? (
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 50 }} />
      ) : items.length === 0 ? (
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
          <Feather name="shopping-cart" size={60} color="#ccc" style={{ marginBottom: 15 }} />
          <Text style={sharedStyles.empty}>ยังไม่มีวิชาในตะกร้า</Text>
        </View>
      ) : (
        <>
          {/* ✅ แสดงจำนวนหน่วยกิตรวม */}
          <View style={{ backgroundColor: "#EBF5FB", padding: 12, marginHorizontal: 15, marginTop: 10, borderRadius: 10, flexDirection: "row", justifyContent: "space-between" }}>
            <Text style={{ color: COLORS.primary, fontWeight: "bold" }}>รวม {items.length} วิชา</Text>
            <Text style={{ color: COLORS.primary, fontWeight: "bold" }}>~{totalCredits} หน่วยกิต</Text>
          </View>

          <FlatList
            data={items}
            keyExtractor={(item) => item.course_code}
            contentContainerStyle={{ padding: 15, paddingBottom: 120 }}
            renderItem={({ item }) => (
              <View style={sharedStyles.card}>
                <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                  <View style={{ flex: 1 }}>
                    <CourseBadge code={item.course_code} />
                    <Text style={{ fontSize: 14, fontWeight: "bold", marginTop: 8 }}>{item.course_name}</Text>
                    <Text style={{ color: COLORS.textSub, marginTop: 4 }}>
                      กลุ่มเรียน: {item.sections.join(", ")}
                    </Text>
                    {item.time_info ? (
                      <Text style={{ color: COLORS.primary, marginTop: 4, fontSize: 13 }}>
                        <Feather name="clock" size={12} /> {item.time_info}
                      </Text>
                    ) : null}
                  </View>
                  <TouchableOpacity
                    style={{ padding: 10, backgroundColor: "#FCEBEA", borderRadius: 8 }}
                    onPress={() => removeItem(item.course_code)}
                  >
                    <Feather name="trash-2" size={20} color={COLORS.danger} />
                  </TouchableOpacity>
                </View>
              </View>
            )}
          />

          <View style={sharedStyles.bottomBar}>
            <TouchableOpacity
              style={[sharedStyles.actionButton, { backgroundColor: COLORS.success }]}
              onPress={confirmRegistration}
            >
              <Feather name="check-circle" size={20} color="#fff" />
              <Text style={sharedStyles.actionButtonText}>ยืนยันการลงทะเบียน</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </SafeAreaView>
  );
}
