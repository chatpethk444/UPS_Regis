// screens/ManualScreen.js
import React, { useState, useEffect } from "react";
import {
  View, Text, TextInput, TouchableOpacity,
  FlatList, Alert, ActivityIndicator, SafeAreaView,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { ScreenHeader, CourseBadge, COLORS, sharedStyles } from "../components/shared";
import { getAvailableCoursesAPI, getSectionsAPI, addToCartAPI, getCartAPI } from "../api";

export default function ManualScreen({ student, setView }) {
  const [searchQuery, setSearchQuery]       = useState("");
  const [isSearched, setIsSearched]         = useState(false);
  const [courses, setCourses]               = useState([]);
  const [loading, setLoading]               = useState(false);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [sections, setSections]             = useState([]);
  const [loadingSections, setLoadingSections] = useState(false);
  const [cart, setCart]                     = useState([]);

  // โหลดตะกร้าตั้งแต่เปิดหน้า เพื่อใช้เช็กเวลาชน
  useEffect(() => { fetchCartData(); }, []);

  const fetchCartData = async () => {
    try {
      const data = await getCartAPI(student.student_id);
      setCart(data);
    } catch (err) {
      console.error("Fetch Cart Error:", err);
    }
  };

  // เช็กเวลาชนฝั่ง Client ก่อนส่ง API
  const isTimeOverlapping = (sec1, sec2) => {
    if (!sec1.day_of_week || !sec2.day_of_week) return false;
    if (sec1.day_of_week !== sec2.day_of_week) return false;
    const toInt = (t) => parseInt((t || "").replace(":", ""));
    const s1 = toInt(sec1.start_time), e1 = toInt(sec1.end_time);
    const s2 = toInt(sec2.start_time), e2 = toInt(sec2.end_time);
    return s1 < e2 && s2 < e1;
  };

  // ค้นหาวิชา — กรองจาก available courses ของนักศึกษา
  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      return Alert.alert("⚠️ แจ้งเตือน", "กรุณากรอกรหัสวิชาหรือชื่อวิชา");
    }
    setLoading(true);
    try {
      const data = await getAvailableCoursesAPI(student.student_id);
      const q = searchQuery.toLowerCase();
      const filtered = data.filter(
        (c) =>
          c.course_code.toLowerCase().includes(q) ||
          c.course_name.toLowerCase().includes(q)
      );
      setCourses(filtered);
      setIsSearched(true);
      if (filtered.length === 0) Alert.alert("ไม่พบวิชา", "ลองค้นหาด้วยคำอื่นครับ");
    } catch (err) {
      Alert.alert("Error", err.message);
    } finally {
      setLoading(false);
    }
  };

  // กดที่วิชา → เปิด/ปิด Section
  const handleSelectCourse = async (course) => {
    if (selectedCourse?.course_code === course.course_code) {
      setSelectedCourse(null);
      return;
    }
    setSelectedCourse(course);
    setLoadingSections(true);
    try {
      const data = await getSectionsAPI(course.course_code);
      setSections(data);
    } catch (err) {
      Alert.alert("Error", err.message);
    } finally {
      setLoadingSections(false);
    }
  };

  // กดเลือก Section → เพิ่มลงตะกร้า
  const handleAddSection = async (section) => {
    // 1. ที่นั่งเต็ม
    if (section.enrolled_seats >= section.max_seats) {
      return Alert.alert("⚠️ ที่นั่งเต็ม", "ไม่สามารถเลือก Section นี้ได้");
    }

    // 2. เคยเลือกวิชานี้ไปแล้วหรือยัง
    const existing = cart.find((i) => i.course_code === selectedCourse.course_code);
    if (existing) {
      if (String(existing.section_number) === String(section.section_number)) {
        return Alert.alert(
          "✅ เลือกครบแล้ว!",
          `Section ${section.section_number} ถูกเลือกไปแล้ว\nระบบดึงคาบ ท. และ ป. ให้อัตโนมัติ ✨`
        );
      }
      return Alert.alert(
        "❌ ข้ามกลุ่มเรียน",
        `เลือก Section ${existing.section_number} ไปแล้ว ไม่สามารถผสม Section ${section.section_number} ได้`
      );
    }

    // 3. เวลาชน
    const conflict = cart.find((i) => isTimeOverlapping(i, section));
    if (conflict) {
      return Alert.alert("⚠️ เวลาชนกัน!", `ทับซ้อนกับวิชา ${conflict.course_code}`);
    }

    // 4. ส่ง API
    try {
      await addToCartAPI(student.student_id, selectedCourse.course_code, String(section.section_number));
      Alert.alert("✅ สำเร็จ", `เพิ่ม Section ${section.section_number} ลงตะกร้าแล้ว`);
      fetchCartData(); // refresh ตะกร้า
    } catch (err) {
      Alert.alert("❌ ไม่สำเร็จ", err.message);
    }
  };

  return (
    <SafeAreaView style={sharedStyles.container}>
      <ScreenHeader title="จัดตารางเรียนเอง" onBack={() => setView("MENU")} />

      <View style={{ flex: 1, padding: 20 }}>
        {/* ช่องค้นหา */}
        <View style={{ flexDirection: "row", marginBottom: 20 }}>
          <TextInput
            style={{
              flex: 1, backgroundColor: "#FFF",
              paddingHorizontal: 15, paddingVertical: 10,
              borderRadius: 10, borderWidth: 1,
              borderColor: "#DDD", fontSize: 16,
            }}
            placeholder="🔍 รหัสวิชา หรือ ชื่อวิชา..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={handleSearch}
            returnKeyType="search"
          />
          <TouchableOpacity
            style={{
              backgroundColor: COLORS.primary, width: 50,
              justifyContent: "center", alignItems: "center",
              borderRadius: 10, marginLeft: 10,
            }}
            onPress={handleSearch}
          >
            {loading
              ? <ActivityIndicator color="#fff" />
              : <Feather name="search" size={20} color="#fff" />
            }
          </TouchableOpacity>
        </View>

        {/* ผลการค้นหา */}
        {!isSearched ? (
          <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
            <Feather name="search" size={60} color="#DDD" />
            <Text style={{ color: "#999", marginTop: 10, fontSize: 16 }}>
              พิมพ์รหัสวิชาแล้วกดปุ่มแว่นขยาย
            </Text>
          </View>
        ) : (
          <FlatList
            data={courses}
            keyExtractor={(item) => item.course_code}
            ListEmptyComponent={
              <View style={{ alignItems: "center", marginTop: 50 }}>
                <Feather name="inbox" size={50} color="#DDD" />
                <Text style={{ color: "#999", marginTop: 10 }}>ไม่พบวิชาที่ค้นหา</Text>
              </View>
            }
            renderItem={({ item }) => (
              <View style={{ backgroundColor: "#FFF", borderRadius: 12, marginBottom: 12, overflow: "hidden", elevation: 2 }}>
                {/* หัววิชา */}
                <TouchableOpacity
                  onPress={() => handleSelectCourse(item)}
                  style={{ padding: 15, flexDirection: "row", alignItems: "center" }}
                >
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 16, color: COLORS.primary, fontWeight: "bold" }}>
                      {item.course_code}
                    </Text>
                    <Text style={{ fontSize: 14, fontWeight: "bold", color: "#333", marginVertical: 2 }}>
                      {item.course_name}
                    </Text>
                    <Text style={{ fontSize: 12, color: "#777" }}>
                      {item.credits} หน่วยกิต | {item.course_group}
                    </Text>
                  </View>
                  <Feather
                    name={selectedCourse?.course_code === item.course_code ? "chevron-up" : "chevron-down"}
                    size={20} color="#999"
                  />
                </TouchableOpacity>

                {/* Section list */}
                {selectedCourse?.course_code === item.course_code && (
                  <View style={{ backgroundColor: "#F1F3F5", padding: 10 }}>
                    {loadingSections ? (
                      <ActivityIndicator color={COLORS.primary} style={{ margin: 10 }} />
                    ) : sections.length === 0 ? (
                      <Text style={{ textAlign: "center", color: "red", padding: 10 }}>
                        ไม่มีข้อมูลกลุ่มเรียน
                      </Text>
                    ) : (
                      sections.map((sec, idx) => {
                        const isFull = sec.enrolled_seats >= sec.max_seats;
                        const isTheory = sec.type === "T";
                        return (
                          <View
                            key={idx}
                            style={{
                              flexDirection: "row", alignItems: "center",
                              backgroundColor: "#fff", padding: 10,
                              borderRadius: 8, marginBottom: 8,
                              borderLeftWidth: 4,
                              borderLeftColor: isTheory ? COLORS.primary : "#7B1FA2",
                            }}
                          >
                            <View style={{ flex: 1 }}>
                              {/* Sec number + type badge */}
                              <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 4 }}>
                                <Text style={{ fontWeight: "bold", color: COLORS.primary }}>
                                  Sec: {sec.section_number}
                                </Text>
                                <View style={{
                                  marginLeft: 8, paddingHorizontal: 6, paddingVertical: 2,
                                  borderRadius: 4,
                                  backgroundColor: isTheory ? "#E3F2FD" : "#F3E5F5",
                                }}>
                                  <Text style={{
                                    fontSize: 10, fontWeight: "bold",
                                    color: isTheory ? "#1565C0" : "#7B1FA2",
                                  }}>
                                    {isTheory ? "Theory (T)" : "Lab (L)"}
                                  </Text>
                                </View>
                              </View>
                              <Text style={{ fontSize: 13, color: "#555", marginTop: 2 }}>
                                📅 {sec.day_of_week}  ⏰ {sec.start_time} - {sec.end_time}
                              </Text>
                              <Text style={{ fontSize: 13, color: "#555", marginTop: 2 }}>
                                📍 {sec.room}
                              </Text>
                              <Text style={{
                                fontSize: 13, fontWeight: "bold", marginTop: 4,
                                color: isFull ? COLORS.danger : COLORS.success,
                              }}>
                                🪑 {sec.enrolled_seats}/{sec.max_seats} {isFull ? "(เต็ม)" : "(ว่าง)"}
                              </Text>
                            </View>
                            <TouchableOpacity
                              style={{
                                backgroundColor: isFull ? "#CCC" : COLORS.success,
                                paddingVertical: 8, paddingHorizontal: 14,
                                borderRadius: 6, marginLeft: 10,
                              }}
                              disabled={isFull}
                              onPress={() => handleAddSection(sec)}
                            >
                              <Text style={{ color: "#fff", fontWeight: "bold" }}>เลือก</Text>
                            </TouchableOpacity>
                          </View>
                        );
                      })
                    )}
                  </View>
                )}
              </View>
            )}
          />
        )}
      </View>
    </SafeAreaView>
  );
}
