// screens/AIScreen.js
import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  Image,
  ActivityIndicator,
  Alert,
} from "react-native";
import { MaterialIcons, Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { getAvailableCoursesAPI, aiSuggestAPI, addToCartAPI } from "../api";

export default function AIScreen({ student, setView }) {
  // ------------------- LOGIC & STATE -------------------
  const [availableCourses, setAvailableCourses] = useState([]);
  const [selectedCodes, setSelectedCodes] = useState([]);
  const [suggestions, setSuggestions] = useState([]);
  const [calculating, setCalculating] = useState(false);
  const [loadingCourses, setLoadingCourses] = useState(false);

  useEffect(() => {
    if (!student) return;
    loadCourses();
  }, []);

  const loadCourses = async () => {
    setLoadingCourses(true);
    try {
      const data = await getAvailableCoursesAPI(student.student_id);
      setAvailableCourses(Array.isArray(data) ? data : []);
    } catch (err) {
      Alert.alert("ข้อผิดพลาด", err.message);
      setAvailableCourses([]);
    } finally {
      setLoadingCourses(false);
    }
  };

  const toggleCourse = (code) =>
    setSelectedCodes((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code],
    );

  const handleAIProcess = async () => {
    if (selectedCodes.length === 0) {
      Alert.alert(
        "แจ้งเตือน",
        "กรุณาเลือกวิชาอย่างน้อย 1 วิชาก่อนให้ AI จัดตารางครับ",
      );
      return;
    }
    setCalculating(true);
    try {
      const result = await aiSuggestAPI(student.student_id, selectedCodes);
      setSuggestions(result || []);
      if (result.length === 0) {
        Alert.alert(
          "ไม่พบผลลัพธ์",
          "AI ไม่สามารถจัดตารางที่ไม่ชนกันจากวิชาที่เลือกได้ครับ",
        );
      }
    } catch (err) {
      Alert.alert("ข้อผิดพลาด", err.message);
    } finally {
      setCalculating(false);
    }
  };

  const handleAcceptSuggestion = async (plan) => {
    setCalculating(true);
    try {
      // ดักจับโครงสร้างข้อมูลที่ส่งไป API ให้ถูกต้องเสมอ
      for (const rawSec of plan) {
        let code =
          rawSec?.course_code ||
          rawSec?.course_id ||
          rawSec?.code ||
          (typeof rawSec === "string" ? rawSec : null);
        let secNum = rawSec?.section_number || rawSec?.sec || 1;

        if (code) {
          await addToCartAPI(student.student_id, code, secNum);
        }
      }
      Alert.alert("สำเร็จ!", "เพิ่มวิชาในแผนนี้ลงตะกร้าเรียบร้อยแล้ว 🎉", [
        { text: "ไปที่ตะกร้า", onPress: () => setView("CART") },
        { text: "เลือกวิชาต่อ", onPress: () => setSuggestions([]) },
      ]);
    } catch (err) {
      Alert.alert("ข้อผิดพลาด", err.message);
    } finally {
      setCalculating(false);
    }
  };

  // ------------------- UI -------------------
  return (
    <LinearGradient colors={["#FFDAE4", "#FFF8F8"]} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        {/* Top AppBar */}
        <View style={styles.header}>
          <TouchableOpacity
            onPress={() => setView("MENU")}
            style={styles.menuButton}
          >
            <MaterialIcons name="arrow-back" size={28} color="#7b5455" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>AI Scheduler</Text>
          <TouchableOpacity style={styles.profileButton}>
            <Image
              source={{
                uri: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
              }}
              style={styles.profileImage}
            />
          </TouchableOpacity>
        </View>

        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          {/* Hero Section */}
          <View style={styles.heroSection}>
            <View style={styles.heroTextContainer}>
              <Text style={styles.heroTitle}>ระบบจัดตารางเรียนอัจฉริยะ</Text>
              <Text style={styles.heroSubtitle}>
                ให้ AI ช่วยวิเคราะห์และจัดแผนการเรียนที่ดีที่สุด
                สำหรับคุณในภาคเรียนนี้
              </Text>
            </View>
            <View style={styles.heroImageContainer}>
              <MaterialIcons
                name="auto-awesome"
                size={60}
                color="#a73355"
                style={{ opacity: 0.8 }}
              />
            </View>
          </View>

          {/* Section: Logic Switcher */}
          {suggestions.length > 0 ? (
            /* 🟢 แสดงแผนการเรียนที่ AI จัดมาให้ */
            <View style={styles.plansSection}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>แผนการเรียนที่แนะนำ</Text>
                <TouchableOpacity onPress={() => setSuggestions([])}>
                  <Text style={styles.resetText}>จัดใหม่</Text>
                </TouchableOpacity>
              </View>

              {suggestions.map((plan, index) => {
                const isRecommended = index === 0;
                const planLetter = String.fromCharCode(65 + index);

                return (
                  <View
                    key={index}
                    style={[
                      styles.planCard,
                      isRecommended && styles.planCardRecommended,
                    ]}
                  >
                    <View style={styles.planHeaderRow}>
                      <Text style={styles.planTitle}>
                        Plan {planLetter}
                      </Text>
                      {isRecommended && (
                        <View style={styles.badgeRecommended}>
                          <Text style={styles.badgeText}>แนะนำ</Text>
                        </View>
                      )}
                    </View>

                    {/* รายละเอียดวิชาในแผนการเรียน (ใส่ระบบดักจับข้อมูล) */}
                    <View style={styles.planDetailsContainer}>
                      {plan.map((rawSec, idx) => {
                        // 1. ดึงรหัสวิชาอย่างปลอดภัย
                        let code =
                          rawSec?.course_code ||
                          rawSec?.course_id ||
                          rawSec?.code;
                        if (!code && typeof rawSec === "string") code = rawSec;

                        // 2. ค้นหาชื่อวิชา
                        const courseInfo =
                          availableCourses.find(
                            (c) => c.course_code === code,
                          ) || {};
                        const name =
                          rawSec?.course_name ||
                          courseInfo.course_name ||
                          "ไม่ระบุชื่อวิชา";

                        // 3. ดึง Section, ผู้สอน, วันเวลา, และห้อง (รองรับ class_times array ตามที่ขอ)
                        const secNum =
                          rawSec?.section_number || rawSec?.sec || "??";
                        const instructor = rawSec?.instructor || "N/A";

                        // จัดการข้อมูลเวลาและห้องจาก class_times[0] (ถ้ามี) หรือแบบแบนปกติ
                        // จัดการข้อมูลเวลาและห้องจาก class_times[0]
                        const firstTime = rawSec?.class_times?.[0] || {};
                        const room = firstTime.room || rawSec?.room || "N/A";
                        const day = firstTime.day || rawSec?.day_of_week || "";

                        // สร้างข้อความเวลา (แปลงทศนิยมเป็น ชม:นาที ตามโค้ดเก่าของคุณ)
                        let timeText = "ไม่ระบุเวลา";
                        
                        if (firstTime.start !== undefined) {
                          // ฟังก์ชันแปลง 9.5 -> 09:30
                          const formatTime = (timeFloat) => {
                            return `${Math.floor(timeFloat)}:${String(Math.round((timeFloat % 1) * 60)).padStart(2, "0")}`;
                          };
                          
                          const startTimeStr = formatTime(firstTime.start);
                          const endTimeStr = firstTime.end !== undefined ? formatTime(firstTime.end) : "";
                          
                          timeText = `${day ? day + " " : ""}${startTimeStr}${endTimeStr ? ` - ${endTimeStr}` : ""} น.`;
                        } 
                        else if (rawSec?.start_time && rawSec?.end_time) {
                          timeText = `${day ? day + " " : ""}${rawSec.start_time}-${rawSec.end_time} น.`;
                        } 
                        else if (day) {
                          timeText = day;
                        }

                        return (
                          <View key={idx} style={styles.planCourseItem}>
                            <View style={styles.planCourseHeader}>
                              <View style={styles.planCourseCodeBadge}>
                                <Text style={styles.planCourseCode}>
                                  {code || "??"}
                                </Text>
                              </View>
                              <Text
                                style={styles.planCourseName}
                                numberOfLines={1}
                              >
                                {name}
                              </Text>
                            </View>

                            <View style={styles.planCourseMetaContainer}>
                              {/* 👤 แสดง Section และผู้สอน */}
                              <View style={styles.planCourseMetaRow}>
                                <Feather
                                  name="user"
                                  size={12}
                                  color="#837375"
                                />
                                <Text style={styles.planCourseMetaText}>
                                  Sec {secNum} | {instructor}
                                </Text>
                              </View>
                              {/* 📅 แสดงเวลา (ดึงจาก class_times แล้ว) */}
                              <View style={styles.planCourseMetaRow}>
                                <Feather
                                  name="clock"
                                  size={12}
                                  color="#837375"
                                />
                                <Text style={styles.planCourseMetaText}>
                                  {timeText}
                                </Text>
                              </View>
                            </View>
                          </View>
                        );
                      })}
                    </View>

                    <TouchableOpacity
                      style={[
                        styles.detailButton,
                        isRecommended
                          ? styles.btnRecommended
                          : styles.btnNormal,
                      ]}
                      onPress={() => handleAcceptSuggestion(plan)}
                    >
                      <Text style={styles.detailButtonText}>
                        เลือกแผนนี้ลงตะกร้า
                      </Text>
                    </TouchableOpacity>
                  </View>
                );
              })}
            </View>
          ) : (
            /* 🔵 แสดงหน้าเลือกรายวิชาเพื่อส่งให้ AI */
            <View style={styles.plansSection}>
              <Text style={styles.sectionTitle}>1. เลือกวิชาเป้าหมาย</Text>
              <Text style={styles.heroSubtitle}>
                เลือกวิชาที่คุณต้องการเรียน แล้วให้ AI จับคู่เวลาที่ไม่ชนกัน
              </Text>

              {loadingCourses ? (
                <ActivityIndicator
                  size="large"
                  color="#a73355"
                  style={{ marginTop: 20 }}
                />
              ) : (
                <View style={styles.coursesList}>
                  {availableCourses.map((c) => {
                    const isSelected = selectedCodes.includes(c.course_code);
                    return (
                      <TouchableOpacity
                        key={c.course_code}
                        style={[
                          styles.courseSelectionCard,
                          isSelected && styles.courseSelectionCardSelected,
                        ]}
                        onPress={() => toggleCourse(c.course_code)}
                        activeOpacity={0.7}
                      >
                        <View style={styles.courseSelectionInfo}>
                          <Text
                            style={[
                              styles.csCode,
                              isSelected && styles.csTextSelected,
                            ]}
                          >
                            {c.course_code}
                          </Text>
                          <Text
                            style={[
                              styles.csName,
                              isSelected && styles.csTextSelected,
                            ]}
                            numberOfLines={1}
                          >
                            {c.course_name}
                          </Text>
                        </View>
                        <View
                          style={[
                            styles.csCreditBadge,
                            isSelected && styles.csCreditBadgeSelected,
                          ]}
                        >
                          <Text
                            style={[
                              styles.csCreditText,
                              isSelected && styles.csTextSelected,
                            ]}
                          >
                            {c.credits || "-"} หน่วยกิต
                          </Text>
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              )}

              {/* ปุ่ม Generate */}
              <TouchableOpacity
                style={[
                  styles.generateButton,
                  selectedCodes.length === 0 && { opacity: 0.5 },
                ]}
                onPress={handleAIProcess}
                disabled={calculating || selectedCodes.length === 0}
              >
                {calculating ? (
                  <ActivityIndicator color="#FFF" />
                ) : (
                  <>
                    <MaterialIcons
                      name="auto-fix-high"
                      size={20}
                      color="#FFF"
                    />
                    <Text style={styles.generateButtonText}>
                      สร้างตารางอัตโนมัติ
                    </Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>

        {/* Bottom Navigation */}
        <View style={styles.bottomNav}>
          <TouchableOpacity
            style={styles.navItem}
            onPress={() => setView("MENU")}
          >
            <MaterialIcons name="home" size={24} color="#837375" />
            <Text style={styles.navText}>หน้าแรก</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.navItem}
            onPress={() => setView("MANUAL")}
          >
            <MaterialIcons name="search" size={24} color="#837375" />
            <Text style={styles.navText}>ค้นหา</Text>
          </TouchableOpacity>
          <View style={styles.navItemActive}>
            <MaterialIcons name="auto-awesome" size={24} color="#a73355" />
            <Text style={styles.navTextActive}>AI Schedule</Text>
          </View>
          <TouchableOpacity
            style={styles.navItem}
            onPress={() => setView("CART")}
          >
            <MaterialIcons name="shopping-cart" size={24} color="#837375" />
            <Text style={styles.navText}>ตะกร้า</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.navItem}
            onPress={() => setView("SCHEDULE")}
          >
            <MaterialIcons name="person" size={24} color="#837375" />
            <Text style={styles.navText}>โปรไฟล์</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </LinearGradient>
  );
}

// ------------------- STYLES -------------------
const styles = StyleSheet.create({
  container: { flex: 1 },
  safeArea: { flex: 1 },
  scrollContent: { paddingBottom: 100 },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 16,
  },
  menuButton: {
    width: 44,
    height: 44,
    backgroundColor: "rgba(255, 255, 255, 0.6)",
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#a73355",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1f1a1c",
    letterSpacing: 0.5,
  },
  profileButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#fff",
    padding: 2,
    shadowColor: "#a73355",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
  },
  profileImage: { width: "100%", height: "100%", borderRadius: 20 },
  heroSection: {
    flexDirection: "row",
    marginHorizontal: 20,
    marginTop: 12,
    padding: 24,
    backgroundColor: "rgba(255, 255, 255, 0.7)",
    borderRadius: 28,
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.8)",
  },
  heroTextContainer: { flex: 1, paddingRight: 16 },
  heroTitle: {
    fontSize: 20,
    fontWeight: "800",
    color: "#1f1a1c",
    marginBottom: 8,
    lineHeight: 28,
  },
  heroSubtitle: { fontSize: 12, color: "#837375", lineHeight: 20 },
  heroImageContainer: {
    width: 80,
    height: 80,
    backgroundColor: "#fff",
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#a73355",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
    elevation: 6,
  },
  plansSection: { paddingHorizontal: 20, marginTop: 32 },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    marginBottom: 20,
  },
  sectionTitle: { fontSize: 18, fontWeight: "bold", color: "#1f1a1c" },
  resetText: {
    fontSize: 14,
    color: "#a73355",
    fontWeight: "bold",
    marginBottom: 2,
  },

  /* 🟢 สไตล์ของการ์ดแผนการเรียน (Plan Cards) */
  planCard: {
    backgroundColor: "rgba(255, 255, 255, 0.8)",
    padding: 20,
    borderRadius: 24,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.9)",
  },
  planCardRecommended: {
    backgroundColor: "#fff",
    shadowColor: "#a73355",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.1,
    shadowRadius: 20,
    elevation: 6,
    borderWidth: 2,
    borderColor: "#FDEEF4",
  },
  planHeaderRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  planTitle: { fontSize: 16, fontWeight: "bold", color: "#1f1a1c" },
  badgeRecommended: {
    backgroundColor: "#a73355",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  badgeText: { color: "white", fontSize: 10, fontWeight: "800" },

  /* รายละเอียดวิชาในแผน */
  planDetailsContainer: { marginBottom: 16 },
  planCourseItem: {
    backgroundColor: "#Fcf6f7",
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: "#f0e6e8",
  },
  planCourseHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 6,
  },
  planCourseCodeBadge: {
    backgroundColor: "#FDEEF4",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    marginRight: 8,
  },
  planCourseCode: { fontSize: 12, fontWeight: "bold", color: "#a73355" },
  planCourseName: {
    flex: 1,
    fontSize: 13,
    fontWeight: "600",
    color: "#1f1a1c",
  },
  planCourseMetaContainer: { marginLeft: 2 },
  planCourseMetaRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
    gap: 6,
  },
  planCourseMetaText: { fontSize: 11, color: "#837375" },

  detailButton: {
    width: "100%",
    height: 44,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
  },
  btnRecommended: {
    backgroundColor: "#FDEEF4",
    borderWidth: 2,
    borderColor: "#a73355",
  },
  btnNormal: {
    backgroundColor: "rgba(255, 255, 255, 0.5)",
    borderWidth: 2,
    borderColor: "rgba(167, 51, 85, 0.2)",
  },
  detailButtonText: { fontSize: 13, fontWeight: "bold", color: "#3F0017" },

  /* 🔵 สไตล์ของการ์ดเลือกวิชา (Course Selection) */
  coursesList: { marginTop: 16, marginBottom: 24 },
  courseSelectionCard: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 16,
    borderRadius: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "#f0e6e8",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.03,
    shadowRadius: 4,
    elevation: 1,
  },
  courseSelectionCardSelected: {
    backgroundColor: "#a73355",
    borderColor: "#a73355",
    shadowColor: "#a73355",
    shadowOpacity: 0.2,
    elevation: 4,
  },
  courseSelectionInfo: { flex: 1, paddingRight: 10 },
  csCode: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#1f1a1c",
    marginBottom: 2,
  },
  csName: { fontSize: 12, color: "#837375" },
  csCreditBadge: {
    backgroundColor: "#fcf6f7",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  csCreditBadgeSelected: { backgroundColor: "rgba(255, 255, 255, 0.2)" },
  csCreditText: { fontSize: 11, fontWeight: "bold", color: "#a73355" },
  csTextSelected: { color: "#ffffff" },

  generateButton: {
    flexDirection: "row",
    backgroundColor: "#a73355",
    height: 56,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
    shadowColor: "#a73355",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 8,
  },
  generateButtonText: { color: "#FFF", fontSize: 16, fontWeight: "bold" },

  /* Bottom Nav */
  bottomNav: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    backgroundColor: "rgba(255, 255, 255, 0.95)",
    paddingHorizontal: 16,
    paddingBottom: 24,
    paddingTop: 12,
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
  },
  navItem: { alignItems: "center", paddingHorizontal: 12 },
  navText: { fontSize: 10, fontWeight: "600", color: "#837375", marginTop: 4 },
  navItemActive: {
    alignItems: "center",
    backgroundColor: "#FDEEF4",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  navTextActive: {
    fontSize: 10,
    fontWeight: "bold",
    color: "#a73355",
    marginTop: 2,
  },
});
