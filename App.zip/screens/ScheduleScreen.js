// screens/ScheduleScreen.js
import React, { useState, useEffect } from "react";
import {
  View, Text, ScrollView,
  Alert, ActivityIndicator, SafeAreaView,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { ScreenHeader, CourseBadge, COLORS, sharedStyles } from "../components/shared";
import { getScheduleAPI } from "../api";

// ลำดับและสีประจำวัน
const DAY_ORDER = {
  Mon: 1, Monday: 1, จันทร์: 1,
  Tue: 2, Tuesday: 2, อังคาร: 2,
  Wed: 3, Wednesday: 3, พุธ: 3,
  Thu: 4, Thursday: 4, พฤหัส: 4, พฤหัสบดี: 4,
  Fri: 5, Friday: 5, ศุกร์: 5,
  Sat: 6, Saturday: 6, เสาร์: 6,
  Sun: 7, Sunday: 7, อาทิตย์: 7,
};

const DAY_COLORS = {
  1: "#FFD700", // จันทร์ — เหลือง
  2: "#FF69B4", // อังคาร — ชมพู
  3: "#4CAF50", // พุธ — เขียว
  4: "#FF8C00", // พฤหัส — ส้ม
  5: "#1976D2", // ศุกร์ — น้ำเงิน
  6: "#8A2BE2", // เสาร์ — ม่วง
  7: "#E53935", // อาทิตย์ — แดง
};

function getDayColor(dayName) {
  const order = DAY_ORDER[dayName?.trim()] ?? 0;
  return DAY_COLORS[order] ?? "#555";
}

// จัดกลุ่มข้อมูลตามวัน แล้วเรียงวัน จ→อา และเรียงเวลาในแต่ละวัน
function groupAndSortSchedule(data) {
  const groups = {};
  data.forEach((item) => {
    const day = item.day_of_week?.trim() || "ไม่ระบุวัน";
    if (!groups[day]) groups[day] = [];
    groups[day].push(item);
  });

  Object.keys(groups).forEach((day) => {
    groups[day].sort((a, b) => {
      const toFloat = (t) => t ? parseFloat(t.replace(":", ".")) : 0;
      return toFloat(a.start_time) - toFloat(b.start_time);
    });
  });

  return Object.keys(groups)
    .map((day) => ({ day, order: DAY_ORDER[day] ?? 99, courses: groups[day] }))
    .sort((a, b) => a.order - b.order);
}

export default function ScheduleScreen({ student, setView }) {
  const [scheduleDays, setScheduleDays]       = useState([]);
  const [loadingSchedule, setLoadingSchedule] = useState(false);

  useEffect(() => { fetchSchedule(); }, []);

  const fetchSchedule = async () => {
    if (!student) return;
    setLoadingSchedule(true);
    try {
      const data = await getScheduleAPI(student.student_id);
      setScheduleDays(groupAndSortSchedule(data));
    } catch (err) {
      Alert.alert("ข้อผิดพลาด", err.message);
    } finally {
      setLoadingSchedule(false);
    }
  };

  // นับ credit รวม
  const totalCredits = scheduleDays
    .flatMap((d) => d.courses)
    .reduce((sum, c) => sum + (parseInt(c.credits) || 0), 0);

  return (
    <SafeAreaView style={sharedStyles.container}>
      <ScreenHeader title="ตารางเรียนของฉัน" onBack={() => setView("MENU")} />

      {loadingSchedule ? (
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 50 }} />
      ) : scheduleDays.length === 0 ? (
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
          <Feather name="calendar" size={60} color="#ccc" style={{ marginBottom: 15 }} />
          <Text style={sharedStyles.empty}>ยังไม่มีวิชาเรียนในตาราง</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>

          {/* สรุป credit รวม */}
          <View style={{
            backgroundColor: "#EBF5FB", padding: 12, borderRadius: 10,
            flexDirection: "row", justifyContent: "space-between", marginBottom: 20,
          }}>
            <Text style={{ color: COLORS.primary, fontWeight: "bold" }}>
              รวม {scheduleDays.flatMap((d) => d.courses).length} วิชา
            </Text>
            <Text style={{ color: COLORS.primary, fontWeight: "bold" }}>
              {totalCredits} หน่วยกิต
            </Text>
          </View>

          {scheduleDays.map((dayGroup, i) => {
            const color = getDayColor(dayGroup.day);
            return (
              <View key={i} style={{ marginBottom: 24 }}>
                {/* หัวข้อวัน */}
                <View style={{ flexDirection: "row", alignItems: "center", marginBottom: 10 }}>
                  <View style={{ width: 6, height: 22, backgroundColor: color, marginRight: 10, borderRadius: 3 }} />
                  <Text style={{ fontSize: 18, fontWeight: "bold", color: "#333" }}>
                    วัน{dayGroup.day}
                  </Text>
                  <Text style={{ marginLeft: 8, fontSize: 13, color: "#999" }}>
                    ({dayGroup.courses.length} คาบ)
                  </Text>
                </View>

                {/* รายวิชา */}
                {dayGroup.courses.map((item, idx) => (
                  <View
                    key={idx}
                    style={[
                      sharedStyles.card,
                      { borderLeftWidth: 5, borderLeftColor: color, marginBottom: 10 },
                    ]}
                  >
                    {/* แถวบน: เวลา + รหัสวิชา */}
                    <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                      <View style={{ flexDirection: "row", alignItems: "center" }}>
                        <Feather name="clock" size={14} color="#555" />
                        <Text style={{ marginLeft: 5, fontWeight: "bold", fontSize: 15, color: "#333" }}>
                          {item.start_time} - {item.end_time} น.
                        </Text>
                      </View>
                      <CourseBadge code={item.course_code} />
                    </View>

                    {/* ชื่อวิชา */}
                    <Text style={{ fontSize: 15, fontWeight: "600", marginTop: 8, color: "#1A1A1A" }}>
                      {item.course_name}
                    </Text>

                    {/* รายละเอียด */}
                    <View style={{ flexDirection: "row", flexWrap: "wrap", marginTop: 6, gap: 12 }}>
                      <Text style={sharedStyles.smallText}>
                        📚 Sec {item.section_number}  |  {item.credits || "-"} หน่วยกิต
                      </Text>
                    </View>
                    <View style={{ flexDirection: "row", flexWrap: "wrap", marginTop: 4, gap: 12 }}>
                      <Text style={sharedStyles.smallText}>
                        <Feather name="map-pin" size={12} /> ห้อง {item.room || "N/A"}
                      </Text>
                      <Text style={sharedStyles.smallText}>
                        👤 {item.instructor || "N/A"}
                      </Text>
                    </View>
                  </View>
                ))}
              </View>
            );
          })}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}
